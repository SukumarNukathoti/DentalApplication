import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-dispelling',
  templateUrl: './dispelling.component.html',
  styleUrls: ['./dispelling.component.css']
})
export class DispellingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
