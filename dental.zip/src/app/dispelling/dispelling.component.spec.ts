import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DispellingComponent } from './dispelling.component';

describe('DispellingComponent', () => {
  let component: DispellingComponent;
  let fixture: ComponentFixture<DispellingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DispellingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DispellingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
