import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-myths',
  templateUrl: './myths.component.html',
  styleUrls: ['./myths.component.css']
})
export class MythsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
navigateTo(route: string) {
    this.router.navigate([route]);
  }
}
