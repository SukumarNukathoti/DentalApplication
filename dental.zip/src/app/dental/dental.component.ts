import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-dental',
  templateUrl: './dental.component.html',
  styleUrls: ['./dental.component.css']
})
export class DentalComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
navigateTo(route: string) {
    this.router.navigate([route]);
  }
}
