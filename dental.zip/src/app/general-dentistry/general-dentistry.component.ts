import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';  

@Component({
  selector: 'app-general-dentistry',
  templateUrl: './general-dentistry.component.html',
  styleUrls: ['./general-dentistry.component.css']
})
export class GeneralDentistryComponent implements OnInit {

  constructor(private router: Router) { }  // Inject Router

  ngOnInit(): void {
    // Component initialization logic
  }

  navigateToPage(page: string): void {
    this.router.navigate([`/${page}`]);  // Navigate based on the clicked page
  }
}
