import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { GeneralDentistryComponent } from './general-dentistry/general-dentistry.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { ExamComponent } from './exam/exam.component';
import { DigitalComponent } from './digital/digital.component';
import { DentalComponent } from './dental/dental.component';
import { TmjComponent } from './tmj/tmj.component';
import { TipsComponent } from './tips/tips.component';
import { RecentComponent } from './recent/recent.component';
import { MythsComponent } from './myths/myths.component';
import { OralComponent } from './oral/oral.component';
import { HowComponent } from './how/how.component';
import { FoodComponent } from './food/food.component';
import { DispellingComponent } from './dispelling/dispelling.component';

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HeaderComponent,
    FooterComponent,
    GeneralDentistryComponent,
    AppointmentComponent,
    ExamComponent,
    DigitalComponent,
    DentalComponent,
    TmjComponent,
    TipsComponent,
    RecentComponent,
    MythsComponent,
    OralComponent,
    HowComponent,
    FoodComponent,
    DispellingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
