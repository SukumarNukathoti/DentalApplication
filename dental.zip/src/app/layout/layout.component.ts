import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute,NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {

  showappointment: boolean = true;
  private routerSubscription: Subscription|null = null;

  constructor(private router: Router, private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
   
    // setTimeout(()=>{
    //   this.checkAppointmentVisibility(this.router.url);
    // })
    this.routerSubscription = this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
       
        this.checkAppointmentVisibility(event.urlAfterRedirects);
      }
    });

    
  }
ngOnDestroy() {
   
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }
  checkAppointmentVisibility(url: string) {
    
    if (url.includes('/s5')|| url.includes('/s6') || url.includes('/s7')) {
      this.showappointment = false; 
    } else {
      this.showappointment = true; 
    }
  }
}