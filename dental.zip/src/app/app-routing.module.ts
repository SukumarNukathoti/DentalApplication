import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ExamComponent } from './exam/exam.component';
import { DigitalComponent } from './digital/digital.component';
import { DentalComponent } from './dental/dental.component';
import { TmjComponent } from './tmj/tmj.component';
import { GeneralDentistryComponent } from './general-dentistry/general-dentistry.component';
import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { TipsComponent } from './tips/tips.component';
import { RecentComponent } from './recent/recent.component';
import { MythsComponent } from './myths/myths.component';
import { HowComponent } from './how/how.component';
import { FoodComponent } from './food/food.component';
import { DispellingComponent } from './dispelling/dispelling.component';
import { OralComponent } from './oral/oral.component';

const routes: Routes = [
  {path:'general-dentistry',component: GeneralDentistryComponent },
  { path: 'exam-cleaning', component: ExamComponent },
  { path: 'digital-x-rays', component: DigitalComponent },
  { path: 'dental-sealants', component: DentalComponent},// 
  { path: 'tmj', component: TmjComponent },
  {path:'tips-for-getting-your-children-to-take-dental-health-seriously',component:TipsComponent},
  {path:'a-recent-study-from-listerine-found-the-brands-antiseptic-does-better-than-flossing-at-reducing-supragingival-plaque',component:RecentComponent},
  {path:'exploring-the-myths-about-fluoride',component:MythsComponent},
  {path:'oral-health-spotlight-the-microorganisms-that-live-in-your-mouth/',component:OralComponent},
  {path:'s9',component:HowComponent},
  {path:'s10',component:FoodComponent},
    {path:'s11',component:DispellingComponent},

  {path:'layout',component:LayoutComponent},
  { path: '', redirectTo: '/general-dentistry', pathMatch: 'full' }  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
