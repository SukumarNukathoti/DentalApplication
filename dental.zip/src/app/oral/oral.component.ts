import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-oral',
  templateUrl: './oral.component.html',
  styleUrls: ['./oral.component.css']
})
export class OralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
