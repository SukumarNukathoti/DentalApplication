import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmjComponent } from './tmj.component';

describe('TmjComponent', () => {
  let component: TmjComponent;
  let fixture: ComponentFixture<TmjComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TmjComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TmjComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
